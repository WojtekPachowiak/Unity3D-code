﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LaserFiring : MonoBehaviour
{

    SpriteRenderer spriteRndr;

    [Header("Laser")]
    [SerializeField]
    float maxBeamStrength = 3.0f;

    [SerializeField]
    float scaleY = 0.7f;
    [SerializeField]
    float scaleYOffset = 0.1f;
    [SerializeField]
    float scaleYChangeSpeed = 1f;

    [SerializeField]
    float beamWarmUpTime = 3.0f;
    [SerializeField]
    float beamWarmUp_Timer;



    [Header("Raycast")]
    [SerializeField]
    LayerMask layerMask;

    [SerializeField]
    Transform muzzle;

    [SerializeField]
    Vector2 direction;

    [SerializeField]
    float distance;

    [Header("Shockwave")]
    [SerializeField]
    GameObject shockwaveGO;
    [SerializeField]
    SpriteRenderer shockwaveSpriteRndr;
    [SerializeField]
    float shockwaveFalloffMultiplier;
    [SerializeField]
    SpriteRenderer haloSpriteRndr;
    [SerializeField]
    float haloIntensity;



    void Start()
    {
        spriteRndr = GetComponent<SpriteRenderer>();
    }


	public void Fire() {
        spriteRndr.enabled = true;
        shockwaveGO.SetActive(true);
        StartCoroutine(LaserWarmUp());
        //spriteRndr.material.SetFloat(8, 0.0f);
    }
    public void StopFire() {
        spriteRndr.enabled = false;
        shockwaveGO.SetActive(false);

        //spriteRndr.material.SetFloat(8, 0.0f);
    }
	void Update() {
		if (spriteRndr.enabled && beamWarmUp_Timer > beamWarmUpTime) {
            this.transform.localScale = new Vector3(this.transform.localScale.x, scaleY + Mathf.Sin(Time.time * scaleYChangeSpeed) * scaleYOffset, this.transform.localScale.z);
		}
	}

	IEnumerator LaserWarmUp() {
        beamWarmUp_Timer = 0.0f;
        while (spriteRndr.enabled) {
            var rayHit = Physics2D.Raycast(muzzle.position, (this.transform.position - muzzle.position).normalized, distance, layerMask);
            if (rayHit) {
                shockwaveGO.transform.position = new Vector3(rayHit.point.x, rayHit.point.y, shockwaveGO.transform.position.z);
                muzzle.localScale = new Vector3(rayHit.distance + 1f, muzzle.localScale.y, muzzle.localScale.z);
                //shockwaveSpriteRndr.enabled = true;
                shockwaveGO.SetActive(true);
            }
			//else {
   //             muzzle.localScale = new Vector3(distance, muzzle.localScale.y, muzzle.localScale.z);

   //             //shockwaveSpriteRndr.enabled = false;
   //             shockwaveGO.SetActive(false);
   //         }

            
            if (beamWarmUp_Timer <= beamWarmUpTime) {
                float t = beamWarmUp_Timer / beamWarmUpTime;
                shockwaveSpriteRndr.material.SetFloat("_FalloffMultiply", shockwaveFalloffMultiplier * t);

                this.transform.localScale = new Vector3(this.transform.localScale.x, scaleY * t, this.transform.localScale.z);

                haloSpriteRndr.material.SetFloat("_Intensity", haloIntensity * t);

                spriteRndr.material.SetFloat("_BeamStrength", Mathf.Lerp(0.0f, maxBeamStrength, t));
                beamWarmUp_Timer += Time.deltaTime;
            }


            else if (beamWarmUp_Timer > beamWarmUpTime) {
                shockwaveSpriteRndr.material.SetFloat("_FalloffMultiply", shockwaveFalloffMultiplier);
                spriteRndr.material.SetFloat("_BeamStrength", maxBeamStrength);
                haloSpriteRndr.material.SetFloat("_Intensity", haloIntensity );
            }
                yield return null;
        }
    }

	private void OnDrawGizmos() {
        Gizmos.color = Color.red;
        //Debug.Log("this.localPos: "+ this.transform.localPosition);
        ////Debug.Log("origin.localPos: " + origin.localPosition);
        //Debug.Log("this.Pos: " + this.transform.position);
        //Debug.Log("origin.Pos: " + origin.position);
        //Gizmos.DrawLine(muzzle.position, transform.position + (transform.position - muzzle.position).normalized * distance);
        Gizmos.DrawLine(muzzle.position, muzzle.position + (this.transform.position-muzzle.position).normalized * distance );

    }
}
