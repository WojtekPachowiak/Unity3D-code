﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Menu : MonoBehaviour
{
    [SerializeField]
    SpriteRenderer transitionScreen_sprt_Rndr;

    //[SerializeField]
    //TextMeshProUGUI text;

    [SerializeField]
    Animator anim_Menu;

    [SerializeField]
    PlayerInput input;

    [SerializeField]
    AnimationScript anim_Player;

    [SerializeField]
    GameObject playerGO;

    [SerializeField]
    Vector2 transitionRange = new Vector2(1f, -0.1f);
    public float transitionPhase;

    [SerializeField]
    GameObject gameplay_Objects;

    [SerializeField]
    GameObject menu_Objects;

    [SerializeField]
    GameObject[] cameras;

    [SerializeField]
    SineAlpha pressButtonSine;

    // Start is called before the first frame update
    void Start() {
        transitionPhase = transitionRange.x;

        //SpriteRenderer playerSpriteRndr =

        StartCoroutine(MenuCouroutine());
    }

	

    IEnumerator MenuCouroutine() {
        //--------------------------------------------
        pressButtonSine.isStarted = false;
        gameplay_Objects.SetActive(false);
        anim_Menu.Play("ControlsFadeIn");
        yield return null;
        while (anim_Menu.GetCurrentAnimatorStateInfo(0).normalizedTime < 1f) {
            yield return null;
        }
        pressButtonSine.isStarted = true;
        //--------------------------------------------
        anim_Menu.Play("Controls");
        yield return null;
        while (!Input.anyKeyDown) {
            Debug.Log("Waiting for input");
            yield return null;
        }
        //--------------------------------------------
        gameplay_Objects.SetActive(true);
        playerGO.SetActive(false);
        playerGO.GetComponent<SpriteRenderer>().enabled = false;

        anim_Menu.Play("ControlsFadeOut");
        yield return null;
        Debug.Log("ControlsFadeOut? " + anim_Menu.GetCurrentAnimatorStateInfo(0).IsName("ControlsFadeOut"));
        while (anim_Menu.GetCurrentAnimatorStateInfo(0).normalizedTime < 1f) {
            transitionScreen_sprt_Rndr.material.SetFloat("_threshhold", transitionPhase);
            yield return null;
        }
        //transitionScreen_sprt_Rndr.material.SetFloat("_threshhold", transitionRange.y);
        //--------------------------------------------
        menu_Objects.SetActive(false);
        playerGO.SetActive(true);
        playerGO.GetComponent<SpriteRenderer>().enabled = true;

        anim_Menu.Play("PlayerAppears");
        yield return null;
        while (anim_Menu.GetCurrentAnimatorStateInfo(0).normalizedTime < 1f) {
			yield return null;
		}
        Debug.Log("Koniec");
        menu_Objects.SetActive(false);

        //SwitchCameras();
        //StartCoroutine(anim_Player.TeleAppearing());
    }

    void SwitchCameras() {
        cameras[0].SetActive(!cameras[0].activeSelf);
        cameras[1].SetActive(!cameras[1].activeSelf);
    }



}
