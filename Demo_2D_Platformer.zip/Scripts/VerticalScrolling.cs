﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VerticalScrolling : MonoBehaviour
{
    [SerializeField]
    GameObject cam;

    [SerializeField]
    Vector2 verticalScrollingRange = new Vector2(0.0f, 30.0f);

    [SerializeField]
    Vector2 offsetRange = new Vector2(10.0f, -10.0f);

    [SerializeField]
    Vector2 backgroundImageRes = new Vector2(2000.0f, 1000.0f);

    [SerializeField]
    int vertImagesNum = 2;

    float startHeight;

	private void Start() {
        startHeight = this.transform.position.y;

    }

	void Update()
    {
        float t = Mathf.Clamp(cam.transform.position.y, verticalScrollingRange.x, verticalScrollingRange.y) / verticalScrollingRange.y;
        float offset = Mathf.Lerp(offsetRange.x, offsetRange.y, t);

        this.transform.localPosition = new Vector3(this.transform.localPosition.x, offset, this.transform.localPosition.z);
        //this.transform.localPosition = Mathf.Clamp(this.transform.localPosition, )

        //cam.transform.position.y == 0f;
        //then
        //this.transform.position.y += backgroundImageRes.y * 0.5f;

        //cam.transform.position.y == 30f;
        //then
        //this.transform.position.y += backgroundImageRes.y * -1.5f;

    }
}
