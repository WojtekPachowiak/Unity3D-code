﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GhostTrail : MonoBehaviour
{

    [SerializeField]
    RenderTexture rndrTex;

    [SerializeField]
    SpriteRenderer sprtRndr;

    [SerializeField]
    GameObject ghostPrefab;

    [SerializeField]
    PlayerMovement move;

    [SerializeField]
    float delay;

    [SerializeField]
    float lifetime;

    [SerializeField]
    float ghostSizePerPixel = 100f;


    float timer;
    int maxGhosts;
    int currentGhost = 0;
    GameObject[] ghosts;
    Texture2D[] textures;

    //[Header("ShaderProperties")]
    //[SerializeField]
    //float falloffSpeed;

    //[SerializeField]
    //Color color;

    //[SerializeField]
    //int _lifetimeTopower;

    // Start is called before the first frame update
    void Start()
    {
        maxGhosts = Mathf.FloorToInt(lifetime / delay);
        ghosts = new GameObject[maxGhosts];
        textures = new Texture2D[maxGhosts];

        for (int i = 0; i < maxGhosts; i++) {
            GameObject ghost = Instantiate(ghostPrefab, transform.position, transform.rotation);
            ghost.GetComponent<SpriteRenderer>().sortingOrder = sprtRndr.sortingOrder -1;
            ghosts[i] = ghost;
            textures[i] = new Texture2D(rndrTex.width, rndrTex.height, TextureFormat.RGB24, false);

        }

        timer = delay;

    }

    // Update is called once per frame
    void Update()
    {
        if (move.isJumping) {
            timer -= Time.deltaTime;

            if (timer <= 0f) {
                timer = delay;
                CreateGhost();
            }
        }
        else {
            timer = delay;

        }
        //for (int i = 0; i < maxGhosts; i++) {
        //    ghosts[i].GetComponent<SpriteRenderer>().material.SetFloat("_FadeoffSpeed", falloffSpeed);
        //    ghosts[i].GetComponent<SpriteRenderer>().material.SetColor("_Color", color);
        //    ghosts[i].GetComponent<SpriteRenderer>().material.SetInt("_lifetimeTopower", _lifetimeTopower);


        //}

    }

    void CreateGhost() {
        GameObject ghost = ghosts[currentGhost];
        ghost.transform.position = transform.position;
        SpriteRenderer sprtRndr_ghost = ghost.GetComponent<SpriteRenderer>();
        //Texture2D sprtTex = toTexture2D(rndrTex);
        toTexture2D(rndrTex);
        //Texture2D sprtTex = Texture2D.whiteTexture;
        //sprtTex.Resize(rndrTex.width, rndrTex.height);
        sprtRndr_ghost.sprite = Sprite.Create(textures[currentGhost], new Rect(0.0f, 0.0f, textures[currentGhost].width, textures[currentGhost].height), new Vector2(0.5f, 0.5f), ghostSizePerPixel);
        StartCoroutine(ChangeColor(lifetime, sprtRndr_ghost, ghost));
        currentGhost = (currentGhost+1) % maxGhosts;
    }

    IEnumerator ChangeColor(float _lifeTime, SpriteRenderer sprtRndr_ghost, GameObject ghost) {

        float orig_time = _lifeTime;
        while (_lifeTime > 0f) {
            _lifeTime -= Time.deltaTime;

            //sprtRndr_ghost.color -= new Color(0, 0, 0, Time.deltaTime / orig_time);
            sprtRndr_ghost.material.SetFloat("_lifetime",_lifeTime/ orig_time);

            //sprtRndr_ghost.color = Color.Lerp(fadingColor, sprtRndr_ghost.color, _lifeTime / orig_time);
            yield return null;
        }



	}


    void toTexture2D(RenderTexture rTex) {
        //Texture2D tex = new Texture2D(rTex.width, rTex.height, TextureFormat.RGB24, false);
        var old_rt = RenderTexture.active;

        RenderTexture.active = rTex;
        textures[currentGhost].ReadPixels(new Rect(0, 0, rTex.width, rTex.height), 0, 0);
        textures[currentGhost].Apply();
        RenderTexture.active = old_rt;

    }
}
