﻿//using System.Collections;
//using System.Collections.Generic;
//using UnityEngine;

//public class PlayerAnimationScript : MonoBehaviour
//{

//    [SerializeField]
//    private GameObject combatGO;

//    private Animator animVisual;
//    private Animator animCombat;
//    private PlayerCombat combat;
//    private PlayerMovement move;
//    private PlayerCollision coll;
    
//    //private PlayerGravity grav;


//    //Movement
//    const string IDLE = "Idle";
//    const string WALK = "Walk";
//    const string CROUCH_WALK = "Crouch_Walk";
//    const string CROUCH_STAY = "Crouch_Stay";
//    const string FALLING = "Falling";
//    const string JUMP = "Jump";

//    //Combat
//    const string ATTACK_SLASH = "Attack_Slash";
//    const string ATTACK_STAB = "Attack_Stab";
//    const string ATTACK_IDLE = "Attack_Idle";
//    private float animCombatTimer = 0f;
//    private Dictionary<string, float> animCombatClipsDict;


    


//    //string currentState = IDLE;
//    void Start()
//    {
//        animCombat = combatGO.transform.GetComponent<Animator>();
//        animVisual = GetComponent<Animator>();

//        combat = combatGO.transform.GetComponent<PlayerCombat>();
//        coll = GetComponentInParent<PlayerCollision>();
//        move = GetComponentInParent<PlayerMovement>();

//        animCombatClipsDict = FillAnimClipsDict(animCombat);
//    }

//    void Update()
//    {
//		animVisual.SetBool("onGround", coll.onGround);


//        //      AnimatorStateInfo animSInfo = animCombat.GetCurrentAnimatorStateInfo(0);

//        //      if (animSInfo.IsName(ATTACK_SLASH) || animSInfo.IsName(ATTACK_STAB)) {
//        //}


//        //---------------ATTACK_STAB, ATTACK_SLASH, ATTACK_IDLE--------------
//        if (Time.time >= animCombatTimer) {

//            if (!combat.AStab && !combat.ASlash) {
//                animCombat.Play(ATTACK_IDLE);
//            }
//			else {
//                if (combat.ASlash) {
//                    animCombat.Play(ATTACK_SLASH);
//                    animCombatTimer = animCombatClipsDict[ATTACK_SLASH];
//                }
//                else if (combat.AStab) {
//                    animCombat.Play(ATTACK_STAB); 
//                     animCombatTimer = animCombatClipsDict[ATTACK_STAB];
//                }
//                animCombatTimer = Time.time + animCombatTimer;
//                //animCombatTimer = Time.time + animCombat.GetCurrentAnimatorStateInfo(0).length;
//            }

//        }




//        //---------------JUMP, FALLING--------------
//        if (move.isJumping) {

//            if(move.rb.velocity.y > 0) {
//                animVisual.Play(JUMP);
//                return;
//            }
//            else if (move.rb.velocity.y < 0) {
//                animVisual.Play(FALLING);
//                return;
//            }
            
//        }
//        //---------------CROUCH_STAY, CROUCH_WALK--------------
//        if (move.isCrouching) {
//            if (PlayerInput.inst.dir.x == 0) {
//                animVisual.Play(CROUCH_STAY);
//                return;
//            }
//            else if (PlayerInput.inst.dir.x != 0) {
//                animVisual.Play(CROUCH_WALK);
//                return;
//            }
//		}

//        //---------------IDLE, WALK--------------
//        if (PlayerInput.inst.dir.x == 0) {
//			animVisual.Play(IDLE);
//			return;
//		}
//		else if (PlayerInput.inst.dir.x != 0) {
//            animVisual.Play(WALK);
//            return;
//        }
//    }




//    public Dictionary<string, float> FillAnimClipsDict(Animator anim) {

//        Dictionary<string, float> animClipsDict = new Dictionary<string, float>();
//        AnimationClip[] clips = anim.runtimeAnimatorController.animationClips;

//        foreach (AnimationClip clip in clips) {
//            animClipsDict.Add(clip.name, clip.length);
//        }

//        return animClipsDict;
//    }


//    //public void AnimHDir(float xDir)
//    //{
//    //    animVisual.SetFloat("hDir", xDir);
//    //}

//    //public void AnimVDir(float yDir) {
//    //    animVisual.SetFloat("vDir", yDir);
//    //}

//    //public void AnimYVel(float yVel) {
//    //    animVisual.SetFloat("vVel", yVel);
//    //}

//    //public void AnimCrouch(bool crouch) {
//    //    animVisual.SetBool("isCrouching", crouch);
//    //}

//    ////public void AnimCrouch(bool crouch) {
//    ////    anim.SetBool("isRunning", crouch);
//    ////}


//    //public void AnimJump() {
//    //    animVisual.SetTrigger("hasJumped");
//    //}
    


    
//}
