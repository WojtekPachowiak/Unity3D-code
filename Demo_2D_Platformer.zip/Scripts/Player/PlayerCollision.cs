﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerCollision : MonoBehaviour
{

    [Header("Layers")]
    public LayerMask groundLayer;

    [Space]

    public bool onGround;
    //public bool onWall;
    //public bool onRightWall;
    //public bool onLeftWall;
    //public int wallSide;

    [Space]

    [Header("Collision")]
    public Vector2 wCollSize, wCollOffset;
    public Vector2 gCollSize, gCollOffset;

    private Color debugCollisionColor = Color.red;


    // Update is called once per frame
    void FixedUpdate()
    {
        onGround = Physics2D.OverlapBox((Vector2)transform.position + gCollOffset, gCollSize,0, groundLayer);

        //      onWall = Physics2D.OverlapBox((Vector2)transform.position - wCollOffset, wCollSize,0, groundLayer) 
        //          || Physics2D.OverlapBox((Vector2)transform.position + wCollOffset, wCollSize,0, groundLayer);

        //      //Debug.Log(Physics2D.OverlapBox((Vector2)transform.position - wCollOffset, wCollSize, groundLayer).gameObject.name);
        //      //Debug.Log(Physics2D.OverlapBox((Vector2)transform.position + wCollOffset, wCollSize, groundLayer).gameObject.name);

        //      if (onWall)
        //{
        //          onRightWall = Physics2D.OverlapBox((Vector2)transform.position - wCollOffset, wCollSize,0, groundLayer);
        //          if (!onRightWall)
        //              onLeftWall = Physics2D.OverlapBox((Vector2)transform.position + wCollOffset, wCollSize,0, groundLayer);
        //      }

        //      wallSide = onRightWall ? -1 : 1;
    }

    void OnDrawGizmos()
    {
        Gizmos.color = debugCollisionColor;
        
        //Gizmos.DrawWireCube((Vector2)transform.position - wCollOffset, wCollSize);
        //Gizmos.DrawWireCube((Vector2)transform.position + wCollOffset, wCollSize);
        Gizmos.DrawWireCube((Vector2)transform.position + gCollOffset, gCollSize);

    }
}
