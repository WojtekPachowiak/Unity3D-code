﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerGravity : MonoBehaviour
{
    [SerializeField]
	private Rigidbody2D rb;

    [SerializeField]
    private PlayerInput input;

    

    [SerializeField]
    private ScrptObj_PlayerStats stats;

    void Update()
    {
        if(rb.velocity.y < 0)
        {
            rb.gravityScale = stats.fallG;
            //rb.velocity += Vector2.up * Physics2D.gravity.y * (fallMultiplier - 1) * Time.deltaTime;
        }
        else if(rb.velocity.y > 0 && input.jumpButtPress)
        {
            //rb.velocity += Vector2.up * Physics2D.gravity.y * (lowJumpMultiplier - 1) * Time.deltaTime;
            rb.gravityScale = stats.highJumpG;
        }
		else {
            rb.gravityScale = stats.lowJumpG;

        }
    }
}
