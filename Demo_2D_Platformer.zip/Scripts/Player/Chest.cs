﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Chest : MonoBehaviour, I_Interactable {


	[SerializeField]
    private Animator anim;
    

    public void Interact() {
        anim.Play("Open");
	}



    
}
