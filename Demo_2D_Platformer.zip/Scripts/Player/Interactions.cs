﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Interactions : MonoBehaviour
{
    

	//private void OnTriggerEnter2D(Collider2D coll) {
 //       if (PlayerInput.inst.interactButtPress && coll is I_Interactable) {
 //           coll.GetComponent<I_Interactable>().Interact();
 //       }
	//}
}
