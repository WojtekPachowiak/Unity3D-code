﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AnimationScript : MonoBehaviour
{

    //private GameObject combatGO;
    [SerializeField]
    private Animator anim;
    //private Animator animCombat;
    //private PlayerCombat combat;

    [SerializeField]
    private PlayerMovement move;

    [SerializeField]
    private PlayerCollision coll;

    [SerializeField]
    private Combat combat;

    [SerializeField]
    private PlayerInput input;

    [SerializeField]
    private Menu menu;
    //private PlayerGravity grav;


    //Movement
    const string IDLE = "Idle";
    const string WALK = "Walk";
    const string CROUCH_WALK = "Crouch_Walk";
    const string CROUCH_STAY = "Crouch_Stay";
    const string FALLING = "Falling";
    const string FALLING_WALK = "Falling_Walk";

    const string JUMP = "Jump";
    const string LANDING = "Landing";
    const string DASHING = "Dashing";

    const string TELEPORT_APPEAR = "Teleport_Appear";
    const string TELEPORT_UNFOLD = "Teleport_Unfold";




    //Combat
    const string FIRE = "Fire";

    const string ATTACK_SLASH = "Attack_Slash";
    const string ATTACK_STAB = "Attack_Stab";
    const string ATTACK_IDLE = "Attack_Idle";
    private float animCombatTimer = 0f;
    private Dictionary<string, float> animCombatClipsDict;


    string currentAnimClip;

    bool animatorEnabled = true;

    public bool isTeleportAppearing = false;
    public bool isTeleportUnfolding = false;


    //string currentState = IDLE;
    void Start()
    {
        //animCombat = combatGO.transform.GetComponent<Animator>();
        //anim = GetComponent<Animator>();

        ////combat = combatGO.transform.GetComponent<PlayerCombat>();
        //coll = GetComponent<PlayerCollision>();
        //move = GetComponent<PlayerMovement>();

        //animCombatClipsDict = FillAnimClipsDict(animCombat);
    }

    void Update()
    {
        //anim.SetBool("onGround", coll.onGround);


        //      AnimatorStateInfo animSInfo = animCombat.GetCurrentAnimatorStateInfo(0);

        //      if (animSInfo.IsName(ATTACK_SLASH) || animSInfo.IsName(ATTACK_STAB)) {
        //}


        //---------------ATTACK_STAB, ATTACK_SLASH, ATTACK_IDLE--------------
        //     if (Time.time >= animCombatTimer) {

        //         if (!combat.AStab && !combat.ASlash) {
        //             animCombat.Play(ATTACK_IDLE);
        //         }
        //else {
        //             if (combat.ASlash) {
        //                 animCombat.Play(ATTACK_SLASH);
        //                 animCombatTimer = animCombatClipsDict[ATTACK_SLASH];
        //             }
        //             else if (combat.AStab) {
        //                 animCombat.Play(ATTACK_STAB); 
        //                  animCombatTimer = animCombatClipsDict[ATTACK_STAB];
        //             }
        //             animCombatTimer = Time.time + animCombatTimer;
        //             //animCombatTimer = Time.time + animCombat.GetCurrentAnimatorStateInfo(0).length;
        //         }

        //     }



        if (!animatorEnabled) {
            return;
		}

        anim.SetBool(currentAnimClip, false);



        //---------------TELEPORT--------------
        
        if (isTeleportUnfolding) {
            SetBool(TELEPORT_UNFOLD);
            return;
        }

        //---------------DASHING--------------
        if (move.isDashing || move.hasDashed) {
            SetBool(DASHING);
            return;
		}
		//---------------LANDING--------------
		if (move.isLanding) {
            SetBool(LANDING);
			return;
		}
        //---------------JUMP, FALLING--------------
        
        if (move.isJumping) {

			//if (move.rb.velocity.y > 0) {
   //             anim.SetBool(JUMP, true);
   //             currentAnimClip = JUMP;
   //         }
            if (move.isFalling) {
                SetBool(FALLING);
                
            }
            else {
                anim.SetBool(JUMP, true);
                currentAnimClip = JUMP;
            }
            return;
        }
        else if (move.isFalling) {
			SetBool(FALLING_WALK);
			return;
        }

        //FIRING
        if (combat.isFiring) {
            SetBool(FIRE);
            return;
        }
        //---------------CROUCH_STAY, CROUCH_WALK--------------
        if (move.isCrouching) {
            //if (move.dir.x == 0) {
            anim.SetBool(CROUCH_STAY, true);
            currentAnimClip = CROUCH_STAY;
            //}
            //else if (move.dir.x != 0) {
            //    anim.Play(CROUCH_WALK);
            //}
            return;

        }

        //---------------IDLE, WALK--------------
        if (input.dir.x == 0) {
            anim.SetBool(IDLE, true);
            currentAnimClip = IDLE;
            return;
		}
		else if (input.dir.x != 0) {
            anim.SetBool(WALK, true);
            currentAnimClip = WALK;
            return;
        }
    }




    void SetBool(string clipName) {
        anim.SetBool(clipName, true);
        currentAnimClip = clipName;
    }



    public Dictionary<string, float> FillAnimClipsDict(Animator anim) {

        Dictionary<string, float> animClipsDict = new Dictionary<string, float>();
        AnimationClip[] clips = anim.runtimeAnimatorController.animationClips;

        foreach (AnimationClip clip in clips) {
            animClipsDict.Add(clip.name, clip.length);
        }

        return animClipsDict;
    }


    public IEnumerator TeleAppearing() {
        anim.Play(TELEPORT_APPEAR);
        while (anim.GetCurrentAnimatorStateInfo(0).normalizedTime < 1f) {
            yield return null;
        }
        animatorEnabled = true;
        input.inputEnabled = true;
    }

    //void ChangeTransitionDuration(float value) {
    //    // Get a reference to the Animator Controller:
    //    UnityEditor.Animations.AnimatorController ac = anim.runtimeAnimatorController as UnityEditor.Animations.AnimatorController;
    //    //This part is IMPORTANT ^^

    //    // Number of layers:
    //    int layerCount = ac.layers.Length;
    //    Debug.Log(string.Format("Layer Count: {0}", layerCount));

    //    // Names of each layer:
    //    for (int layer = 0; layer < layerCount; layer++) {
    //        Debug.Log(string.Format("Layer {0}: {1}", layer, ac.layers[layer].name));
    //    }

    //    // States on layer 0:
    //    UnityEditor.Animations.AnimatorStateMachine sm = ac.layers[0].stateMachine;
    //    UnityEditor.Animations.ChildAnimatorState[] states = sm.states;
    //    foreach (UnityEditor.Animations.ChildAnimatorState s in states) {
    //        s.state.
    //        Debug.Log(string.Format("State: {0}", s.state.name));
    //        Debug.Log("print transiotns");

    //        foreach (var t in s.state.transitions) {
    //            Debug.Log("print transiotns_INSIDE");
    //            Debug.Log(string.Format("Transitions: {0}", t.name));


    //        }
    //    }
    //    int desiredState = 0;
    //    int desiredTransition = 0;
    //    // Access the duration variable to change it
    //    ac.layers[0].stateMachine.states[desiredState].state.transitions[desiredTransition].duration = 0f;
    //    // You can split this up into different variables if you like
    //    // I just wrote it all on one line so you could see the path to take
    //}





    //public void AnimHDir(float xDir)
    //{
    //    animVisual.SetFloat("hDir", xDir);
    //}

    //public void AnimVDir(float yDir) {
    //    animVisual.SetFloat("vDir", yDir);
    //}

    //public void AnimYVel(float yVel) {
    //    animVisual.SetFloat("vVel", yVel);
    //}

    //public void AnimCrouch(bool crouch) {
    //    animVisual.SetBool("isCrouching", crouch);
    //}

    ////public void AnimCrouch(bool crouch) {
    ////    anim.SetBool("isRunning", crouch);
    ////}


    //public void AnimJump() {
    //    animVisual.SetTrigger("hasJumped");
    //}





    //    //---------------DASHING--------------
    //        if (move.isDashing) {
    //            anim.Play(DASHING);
    //            return;
    //		}
    ////---------------LANDING--------------
    //if (move.isLanding) {
    //    anim.Play(LANDING);
    //    return;
    //}
    ////---------------JUMP, FALLING--------------
    //if (move.isJumping) {

    //    if (move.rb.velocity.y > 0) {
    //        anim.Play(JUMP);
    //    }
    //    else if (move.rb.velocity.y < 0) {
    //        anim.Play(FALLING);
    //    }
    //    return;
    //}
    ////---------------CROUCH_STAY, CROUCH_WALK--------------
    //if (move.isCrouching) {
    //    //if (move.dir.x == 0) {
    //    anim.Play(CROUCH_STAY);
    //    //}
    //    //else if (move.dir.x != 0) {
    //    //    anim.Play(CROUCH_WALK);
    //    //}
    //    return;

    //}

    ////---------------IDLE, WALK--------------
    //if (input.dir.x == 0) {
    //    anim.Play(IDLE);
    //    return;
    //}
    //else if (input.dir.x != 0) {
    //    anim.Play(WALK);
    //    return;
    //}
}
