﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerSpriteFlip : MonoBehaviour
{

    [HideInInspector]
    public SpriteRenderer sr;

    // Start is called before the first frame update
    void Start()
    {
        sr = GetComponent<SpriteRenderer>();
    }

    public void Flip(int facingDir) {
        this.transform.localScale = new Vector2(facingDir, 1);
        //sr.flipX = (facingDir == 1) ? false : true; ;
    }
}
