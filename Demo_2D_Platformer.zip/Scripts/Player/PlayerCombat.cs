﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerCombat : MonoBehaviour
{
    public bool AStab;
    public bool ASlash;
    

    // Update is called once per frame
    void Update()
    {
        AStab = Input.GetButtonDown("Attack_Stab");
        ASlash =  Input.GetButtonDown("Attack_Slash");
    }
}
