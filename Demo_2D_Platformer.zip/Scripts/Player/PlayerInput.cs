﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerInput : MonoBehaviour
{
    [Header("Inputs")]
    public bool jumpButtPress;
    public bool crouchButtPress;
    public bool dashButtPress;
    public bool interactButtPress;
    public bool fireButtonPress;

    public Vector2 dir;

    public bool inputEnabled = true;

    // Update is called once per frame
    void Update()
    {
        if (inputEnabled) {
            jumpButtPress = Input.GetButton("Jump");
            dashButtPress = Input.GetButtonDown("Dash");
            crouchButtPress = Input.GetButton("Crouch");
            dir = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
            interactButtPress = Input.GetButton("Interact");
            fireButtonPress = Input.GetButton("Fire");
        }
        
    }
}
