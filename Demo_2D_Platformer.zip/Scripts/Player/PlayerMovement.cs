﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{

    [SerializeField]
    private GameObject parent;

    [SerializeField]
    public Rigidbody2D rb;

    [SerializeField]
    private PlayerCollision coll;

    [SerializeField]
    private PlayerInput input;

    //[SerializeField]
    //[SerializeField]
    //Jumps jumpTypes;
    //private PlayerAnimationScript anim;
    //private PlayerSpriteFlip sflip;

    [SerializeField]
    private ScrptObj_PlayerStats stats;


    //float timeJumpButtonPressed = 0.0f;

    float dashTimer;
    float dashCooldownTimer;
    float landingCooldownTimer;
    float fallingTimer;

    [Space]
    [Header("Booleans")]
    public bool isShooting = true;
    //public bool isWallGrabing;
    //public bool wallJumped;
    public bool isCrouching = false;
    public bool isJumping = false;
    public bool isLanding = false;
    public bool aboutToLand = false;
    public bool isDashing = false;
    public bool hasDashed = false;
    public bool isFalling = false;




    private bool groundTouch;
    //private bool hasDashed;

    public int faceDir = 1;




    void Start()
    {
        SetTimers();
    }

    IEnumerator LandingCouroutine(float fallingTime) {

        for (int i = 0; i < Mathf.CeilToInt(fallingTime/stats.landingTimePerFrame); i++)
            yield return null;
        isLanding = false;

    }
    void Update()
    {
        

        CheckTimers();

        DecelerateHorizontal();
        
        if (!isShooting) {
            return;
		}


        if (rb.velocity.y < 0f && !isFalling && !coll.onGround) {
            isFalling = true;
            fallingTimer = 0f;
        }
        else if (isFalling && coll.onGround) {
            isFalling = false;
        }

        if (isLanding) {
            return;
        }

        if (isDashing) {
            if (rb.velocity.y < -stats.stopDashVerticalVelocity && rb.velocity.y > stats.stopDashVerticalVelocity) {
                isDashing = false;
                return;
            }
            rb.velocity = new Vector2(stats.dashSpeed * faceDir, 0f);
            return;
        }
        else if (hasDashed) {
            return;
		}
		

		if (rb.velocity.y <= stats.necessaryLandingVelocity) {
            aboutToLand = true;
        }
        if (aboutToLand && coll.onGround) {
            isLanding = true;
            StartCoroutine(LandingCouroutine(fallingTimer));
            aboutToLand = false;
            return;
        }
        

        if (isJumping && coll.onGround) {
            Jump(false);
        }
        if (input.jumpButtPress && coll.onGround) {
            Jump(true);
        }
        //else if (hasJumped && !wasGrounded && coll.onGround) {
        //    hasJumped = false;
        //    wasGrounded = true;
        //}

        //anim.SetHorizontalMovement(dir.x, dir.y, rb.velocity.y);
        if (input.crouchButtPress && coll.onGround) {
            Crouch(true);
            //anim.AnimCrouch(true);
        }
        else if (!input.crouchButtPress && isCrouching) {
            Crouch(false);
            //anim.AnimCrouch(false);
        }

        if (input.dir.x != 0 && !isCrouching) {
            MoveHorizontal(true);
            TryFlip();
            //anim.AnimHDir(dir.x);
        }
        //else if (dir.x == 0) {
        //}

        if (input.dashButtPress && !isDashing && !hasDashed && coll.onGround) {
            Dash();
		}




        /////////////////////////////////////////////
        //// GROUNDED //
        //if (!coll.onGround)
        //{
        //    wasGrounded = false;
        //}
        ///////////////////////////////////////////
        // WALL GRAB //
        //if (coll.onWall && crouchButtPress)
        //{
        //    WallGrab();
        //}
        //else if (isWallGrabing)
        //{
        //    isWallGrabing = false;
        //    canMove = true;
        //}


        //      ///////////////////////////////////////////
        //      // CROUCH //
        //      if (coll.onGround && crouchButtPress && canMove)
        //{
        //          Crouch();
        //      }
        //      else if (isCrouching)
        //{
        //          isCrouching = false;
        //}


    }

    void SetTimers() {
        landingCooldownTimer = stats.landingCooldown;
        dashTimer = stats.dashTime;
        dashCooldownTimer = stats.dashCooldown;
    }

    void CheckTimers() {
		//     if (isLanding) {

		//         if (landingCooldownTimer < 0f) {
		//             isLanding = false;
		//             landingCooldownTimer = stats.landingCooldown;
		//         }
		//else {
		//             landingCooldownTimer -= Time.deltaTime;
		//         }
		//     }
		if (isFalling) {
            fallingTimer += Time.deltaTime;
        }
       

        if (isDashing) {
            dashTimer -= Time.deltaTime;
            if (dashTimer < 0f) {
                isDashing = false;
                hasDashed = true;
                dashTimer = stats.dashTime;
                rb.velocity = new Vector2(0f, rb.velocity.y);
            }
        }
        else if (hasDashed) {
            dashCooldownTimer -= Time.deltaTime;
            if (dashCooldownTimer < 0f) {
                hasDashed = false;
                dashCooldownTimer = stats.dashCooldown;

            }
        }
    }


    void MoveHorizontal(bool moveH){
        if (moveH) {
            float speed = isCrouching ? stats.crouchSpeed : stats.hSpeed;
            //rb.AddForce(Vector2.right * dir.x * hSpeed, ForceMode2D.Impulse);
            rb.velocity = new Vector2(input.dir.x * speed, rb.velocity.y);
        }
        //else if (!moveH) {
        //    rb.velocity = new Vector2(0f, rb.velocity.y);
        //}
        
    }

    void DecelerateHorizontal() {
        rb.velocity = new Vector2( rb.velocity.x / stats.dragHorizontal, rb.velocity.y);
	}

    void StopHorizontal() {
        rb.velocity = new Vector2(0.0f, rb.velocity.y);
    }

    void Crouch(bool crouch)
	{
        if (crouch)
            isCrouching = true;
        else if (!crouch)
            isCrouching = false;
    }


    void LandingAndTimer(bool land) {
        if (land) {
            isLanding = true;
            landingCooldownTimer = stats.landingCooldown;
        }
		else {
            landingCooldownTimer -= Time.deltaTime;
            if (landingCooldownTimer < 0f) {
                isLanding = false;
            }
        }
        
    }

    void Landing() {
        isLanding = true;
    }






    void Jump(bool on) {
        if (on == true) {
            rb.velocity = new Vector2(rb.velocity.x, stats.jumpSpeed);
            isJumping = true;
        }
        else if (on == false) {
            isJumping = false;
        }
    }
    

    




    void Dash() {
        //rb.velocity = new Vector2(stats.dashSpeed * faceDir, rb.velocity.y);
        //rb.AddForce(transform.right * stats.dashSpeed, ForceMode2D.Impulse);
        isDashing = true;
    }
    

    void TryFlip() {
        int newFaceDir = (int)Mathf.Sign(input.dir.x);
        if (faceDir != newFaceDir) {
            parent.transform.localScale = new Vector2(newFaceDir, 1);
            faceDir = newFaceDir;
        }

        //sflip.Flip(faceDir);
    }




    //   void WallGrab()
    //{
    //       // anim.SetTrigger("isWallGrabbing");
    //       isWallGrabing = true;
    //       rb.velocity = Vector2.zero;
    //       canMove = false;
    //   }





    //void TestMove() {
    //    float timerTMP = 2f;
    //    float multTMP = 1f;
    //    rb.velocity = new Vector2(5f * multTMP, 0f);
    //    if (timerTMP > 0f) {
    //        timerTMP -= Time.deltaTime;
    //    }
    //    else {
    //        timerTMP = 2f;
    //        multTMP = -multTMP;
    //    }
    //}





    //   void ChargedJump2(bool jump, float jumpStrength=0.0f)
    //{
    //       if (jump == true) {
    //           float jumpSpeed = Mathf.Lerp(minJumpSpeed, maxJumpSpeed, jumpStrength);

    //           rb.AddForce(Vector2.up * jumpSpeed, ForceMode2D.Impulse);
    //           //rb.velocity = new Vector2(rb.velocity.x, minJumpSpeed);
    //           isJumping = true;
    //       }
    //       else if (jump == false) {
    //           isJumping = false;
    //       }

    //       //hasJumped = true;
    //   }





    //   void DashAndTimer() {
    //       if (dash && dashCooldownTimer <= 0f) {
    //           rb.velocity = new Vector2(dashSpeed, rb.velocity.y);
    //           isDashing = true;
    //           dashCooldownTimer = dashCooldown;
    //       }
    //       else if (!dash && dashCooldownTimer > 0f) {
    //           dashCooldownTimer -= Time.deltaTime;
    //       }


    //}





    //void ChargedJump() {
    //    if (isJumping && coll.onGround) {
    //        ChargedJump2(false);
    //    }
    //    if (input.jumpButtPress && coll.onGround) {

    //        if (isCrouching) {
    //            if (timeJumpButtonPressed <= maxTimeJumpButtonPressed)
    //                timeJumpButtonPressed += Time.deltaTime;
    //        }
    //        else if (!isCrouching && timeJumpButtonPressed == 0f) {
    //            ChargedJump2(true);
    //        }
    //        else {
    //            timeJumpButtonPressed = 0f;
    //        }
    //        //Jump(true);
    //        //anim.AnimJump();
    //    }
    //    else if (!input.jumpButtPress && coll.onGround && isCrouching) {
    //        float jumpStrength = timeJumpButtonPressed / maxTimeJumpButtonPressed;
    //        ChargedJump2(true, jumpStrength);
    //        timeJumpButtonPressed = 0f;
    //        canMoveHorizontal = true;
    //    }
    //}

}


