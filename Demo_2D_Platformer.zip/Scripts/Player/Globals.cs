﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Globals {
	public static Globals globals;

}

public class BackgroundImages {
	public static BackgroundImages inst;



}

public static class Tags {
	public static string interactable = "interactable";
	public static string enemy = "enemy";
}
