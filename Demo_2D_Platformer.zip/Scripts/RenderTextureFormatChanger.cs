﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RenderTextureFormatChanger : MonoBehaviour
{
    [SerializeField]
    RenderTexture rndrTex;
    // Start is called before the first frame update
    void Start()
    {

        rndrTex.format = RenderTextureFormat.RGB111110Float;
    }

}
