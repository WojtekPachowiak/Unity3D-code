﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Halo : MonoBehaviour
{
    [SerializeField]
    PlayerMovement move;

    [SerializeField]
    SpriteRenderer[] halosSprtRndrs;

    [SerializeField]
    bool halosActive = false;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
		if (!halosActive && (move.isCrouching)) {
            SetActiveHalos(true);
        }
		else if (halosActive && (!move.isCrouching)) {
            SetActiveHalos(false);
        }
	}

   void SetActiveHalos(bool active) {
        foreach (var sprtRndr in halosSprtRndrs) {
            sprtRndr.enabled = active;
        }
        halosActive = active;
    }
}
