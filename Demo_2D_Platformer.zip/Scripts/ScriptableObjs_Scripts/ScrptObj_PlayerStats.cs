﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "PlayerStats", menuName = "ScriptableObjects/PlayerStats", order = 1)]
public class ScrptObj_PlayerStats : ScriptableObject
{
        public float hSpeed = 10f;
        public float jumpSpeed = 20f;
        public float crouchSpeed = 5f;

        public float dashTime = 1f;
        public float dashCooldown = 1f;
        public float dashSpeed = 20f;

        public float dragHorizontal = 2f;

        public float landingCooldown = 1f;
        public float landingTimePerFrame = 5f;

        public float necessaryLandingVelocity = -5f;

        public float stopDashVerticalVelocity = 0.5f;

        public float fallG = 2.5f;
        public float lowJumpG = 2f;
        public float highJumpG = 2f;


}


