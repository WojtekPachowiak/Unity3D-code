﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ParticlesManager : MonoBehaviour
{
    [SerializeField]
    ParticleSystem prtclSys;

    [SerializeField]
    PlayerMovement move;
    

    // Update is called once per frame
    void Update()
    {
        this.transform.localScale = new Vector3(move.faceDir, this.transform.localScale.y, this.transform.localScale.z);

        if (move.isDashing) {
            prtclSys.Play();
        }
		else {
            prtclSys.Stop();
        }
    }
}
