﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Combat : MonoBehaviour
{
    [SerializeField]
    PlayerInput input;

    [SerializeField]
    LaserFiring laser;

    [SerializeField]
    PlayerMovement move;

    [SerializeField]
    PlayerCollision coll;
    

    public bool isFiring;



    void Update()
    {
        if (input.fireButtonPress && !isFiring && coll.onGround && !move.isJumping) {
            isFiring = true;
            laser.Fire();
            move.isShooting = false;
        }
		else if (isFiring && !input.fireButtonPress) {
            isFiring = false;
            laser.StopFire();
            move.isShooting = true;
        }
    }
}
