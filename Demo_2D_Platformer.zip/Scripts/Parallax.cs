﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Parallax : MonoBehaviour
{
    float imgLength;
    float imgStartpos;

    [SerializeField]
    GameObject cam;

    [SerializeField]
    [Range(0f, 1f)]
    [Tooltip("1 for nonmoving background; 0 for maximally moving")]
    float parallaxEffect;

   



    // Start is called before the first frame update
    void Start()
    {
        //transform.position = new Vector3(transform.position.x, cam.transform.position.y, transform.position.z); 
        imgStartpos = transform.position.x;

        SpriteRenderer sprtRndr = GetComponent<SpriteRenderer>();

        imgLength = sprtRndr.bounds.size.x;

        CreateImageCopiesOnLeftAndRight(sprtRndr, imgLength, this.transform);
    }

    // Update is called once per frame
    void Update()
    {
        float distMoved_H = (cam.transform.position.x * (1 - parallaxEffect));
        float distToMove_H = (cam.transform.position.x * parallaxEffect);
        transform.position = new Vector3(imgStartpos + distToMove_H, transform.position.y, transform.position.z);

        if (distMoved_H > imgStartpos + imgLength)
            imgStartpos += imgLength;
        else if (distMoved_H < imgStartpos - imgLength)
            imgStartpos -= imgLength;

        //imgStartpos.y = Mathf.Clamp(cam.transform.position.y, verticalScrollingRange.x, verticalScrollingRange.y);
    }

    void CreateImageCopiesOnLeftAndRight(SpriteRenderer _spriteRndr, float _imgLength, Transform _parent) {
        int[] multipliers = { 1, -1 };
        foreach (int mult in multipliers) {
            GameObject copy = new GameObject();
            SpriteRenderer sprtRndrTmp = copy.AddComponent<SpriteRenderer>();
            sprtRndrTmp.sprite = _spriteRndr.sprite;
            sprtRndrTmp.material = _spriteRndr.material;
            sprtRndrTmp.sortingOrder = _spriteRndr.sortingOrder;

            sprtRndrTmp.color = _spriteRndr.color;
            copy.transform.position += new Vector3(_imgLength * mult, 0, 0);
            copy.transform.SetParent(_parent, false);
        }
    }

    
}
