﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Jumps : MonoBehaviour
{
    public void DoubleJump()
	{
		;
	}
}

