﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
public class SineAlpha : MonoBehaviour
{
    [SerializeField]
    float speed;

    [SerializeField]
    float amplitude;

    [SerializeField]
    float offset;

    [SerializeField]
    TextMeshProUGUI text;

    float timer;
    public bool isStarted = false;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (!isStarted) {
            timer = 0f;
        }
		else {
            timer += Time.deltaTime;
        }
        text.color = new Color(text.color.r, text.color.g, text.color.b, (Mathf.Cos(timer * speed)+1f)/2f * amplitude + offset );
    }
}
